// =====================================================
// 🚀 KAINOW BACKEND - SERVIDOR PRINCIPAL
// =====================================================

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const app = express();

// =====================================================
// MIDDLEWARES
// =====================================================

// Segurança HTTP headers
app.use(helmet());

// CORS
app.use(cors({
    origin: process.env.CORS_ORIGINS?.split(',') || '*',
    credentials: true
}));

// Body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}

// =====================================================
// ROTAS
// =====================================================

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV,
        version: '1.0.0'
    });
});

// Importar rotas
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const appointmentRoutes = require('./routes/appointments');
const specialtyRoutes = require('./routes/specialties');
const programRoutes = require('./routes/programs');

// Usar rotas
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/specialties', specialtyRoutes);
app.use('/api/programs', programRoutes);

// Rota 404
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Rota não encontrada'
    });
});

// =====================================================
// ERROR HANDLER
// =====================================================

app.use((err, req, res, next) => {
    console.error('❌ Erro:', err);
    
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Erro interno do servidor',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
});

// =====================================================
// CONECTAR AO BANCO DE DADOS E INICIAR SERVIDOR
// =====================================================

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/kainow';

mongoose
    .connect(MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(() => {
        console.log('✅ Conectado ao MongoDB');
        
        app.listen(PORT, () => {
            console.log(`
╔══════════════════════════════════════════════════════════╗
║         🏥 KAINOW BACKEND - SERVIDOR ATIVO               ║
╚══════════════════════════════════════════════════════════╝

🚀 Servidor rodando em: http://localhost:${PORT}
🗄️  Banco de dados: MongoDB
🌍 Ambiente: ${process.env.NODE_ENV || 'development'}
📡 API Base: http://localhost:${PORT}/api

Rotas disponíveis:
  📍 GET  /api/health              - Status do servidor
  📍 POST /api/auth/register       - Cadastrar usuário
  📍 POST /api/auth/login          - Login
  📍 POST /api/auth/logout         - Logout
  📍 GET  /api/users/me            - Perfil do usuário
  📍 PUT  /api/users/me            - Atualizar perfil
  📍 GET  /api/appointments        - Listar agendamentos
  📍 POST /api/appointments        - Criar agendamento
  📍 GET  /api/specialties         - Listar especialidades
  📍 GET  /api/programs            - Listar programas

✅ Pronto para receber requisições!
            `);
        });
    })
    .catch((err) => {
        console.error('❌ Erro ao conectar ao MongoDB:', err);
        process.exit(1);
    });

// =====================================================
// GRACEFUL SHUTDOWN
// =====================================================

process.on('SIGTERM', () => {
    console.log('👋 SIGTERM recebido. Fechando servidor gracefully...');
    server.close(() => {
        console.log('✅ Servidor fechado');
        mongoose.connection.close(false, () => {
            console.log('✅ Conexão com MongoDB fechada');
            process.exit(0);
        });
    });
});

module.exports = app;
